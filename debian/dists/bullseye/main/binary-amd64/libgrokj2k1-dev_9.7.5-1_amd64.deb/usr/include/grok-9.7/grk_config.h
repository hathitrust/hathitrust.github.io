/*-----------------------------------------------*/
/* Grok Versioning                               */

/* Version number. */
#define GRK_VERSION_MAJOR 9
#define GRK_VERSION_MINOR 7
#define GRK_VERSION_BUILD 5

#define GROK_PLUGIN_NAME  	"grokj2k_plugin" 
